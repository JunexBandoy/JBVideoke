import { createHashRouter } from 'react-router-dom';

import App from './App';
import { PersonalInformationCreate } from './pages/PersonalInformationCreate';
import { PersonalInformationEdit } from './pages/PersonalInformationEdit';
import { PersonalInformationList } from './pages/PersonalInformationList';

export const AppRouter = createHashRouter([
  {
    path: '/',
    element: <App />,
    children: [
      { path: 'personal-informations', element: <PersonalInformationList /> },
      {
        path: 'personal-informations/create',
        element: <PersonalInformationCreate />,
      },
      {
        path: 'personal-informations/:id/edit',
        element: <PersonalInformationEdit />,
      },
    ],
  },
]);
