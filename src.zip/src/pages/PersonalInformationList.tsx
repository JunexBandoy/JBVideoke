import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface PersonalInformationModel {
  id: number;
  firstname: string;
  lastname: string;
  birthDate?: Date;
  email: string;
  phone?: string;
}

interface PersonalInformationList {
  contacts: PersonalInformationModel[];
}

const initialPersonalInfoList: PersonalInformationList = {
  contacts: [],
};

const id = 10;

export const PersonalInformationList: React.FC = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [personalInfoList, setPersonalInfoList] =
    useState<PersonalInformationList>(initialPersonalInfoList);

  useEffect(() => {
    loadPersonalInformation();
  }, [id]);

  const loadPersonalInformation = () => {
    const URL = `https://zirkels-redfalcon-app.dscodelab.com/api/contacts/`;

    fetch(URL, {
      method: 'GET',
      headers: new Headers({
        Accept: 'application/json',
        'Content-Type': 'application/json;charset=UTF-8',
      }),
    })
      .then((response) => response.json() as Promise<PersonalInformationList>)
      .then((data) => {
        setPersonalInfoList(data);
        console.log(data);
        setIsLoading(false);
      });
  };

  if (isLoading) {
    return <div>Is Loading....</div>;
  } else {
    return (
      <>
        <div>
          <button
            className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={() => {
              navigate('/personal-informations/create');
            }}
          >
            Create
          </button>
        </div>
        <div className="flex flex-col">
          <table>
            <tr>
              <td>Name </td>
              <td>Email </td>
              <td>Phone </td>
              <td> </td>
            </tr>
            {personalInfoList.contacts.map((row, index) => (
              <tr key={index}>
                <td>
                  {row.firstname} {row.lastname}
                </td>
                <td>{row.email}</td>
                <td>{row.phone}</td>
                <td>
                  <button
                    className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
                    onClick={() => {
                      alert('Details is not yet implemented');
                    }}
                  >
                    Details
                  </button>
                  <button
                    className="bg-yellow-500 hover:bg-yellow-700 text-black font-bold py-2 px-4 rounded"
                    onClick={() => {
                      navigate(`/personal-informations/${row.id}/edit`);
                    }}
                  >
                    Edit
                  </button>
                  <button
                    className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded"
                    onClick={() => {
                      alert('Deleting is not yet implemented');
                    }}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </table>
        </div>
      </>
    );
  }
};
