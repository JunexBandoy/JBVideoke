import React from 'react';
import { Outlet } from 'react-router-dom';

const App: React.FC = () => {
  return (
    <>
      <div className="bg-sky-900 py-8">
        <h1 className="text-4xl text-center text-yellow-100">
          Personal Information
        </h1>
      </div>
      <div className="bg-slate-200 mx-auto">
        <Outlet />
      </div>
    </>
  );
};

export default App;
